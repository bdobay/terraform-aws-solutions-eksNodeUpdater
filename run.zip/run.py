import json
import os
import boto3

def lambda_handler(event, context):
    aws_region = os.environ['AWS_REGION']
    ec2 = boto3.resource('ec2', region_name = aws_region)
    instances = ec2.create_instances(
        MinCount=1,
        MaxCount=1,
        LaunchTemplate={
        'LaunchTemplateName': 'eksNodeUpdater'
        }
    )
    return {
        'statusCode': 200,
        'body': json.dumps('EC2 created')
    }